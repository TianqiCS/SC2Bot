1, unzip the program
	1.1, .../parent/Feeder and .../parent/SC2API
2, store CactusValleyLE.SC2Map in path .../StarCraftII/Maps/CactusValleyLE.SC2MAP (create Maps directory if there is no Maps)
	2.1, there is a map file in zip, it's in directory Feeder/PUT THIS MAP IN GAME DIRECTORY
3, open Feeder.sln with visual studio
4, Replace/Modify the Run.cpp
	4.1, in Run.cpp: all testing codes must be in #ifdef DEBUG ...main() here... #else ...useless code here... #endif
	4.2, there are more running instrctions' details in default Run.cpp if needed
	4.3, Stepsize should be about 100 for best performance and efficiency
5, set map path in Run like this coordinator.StartGame("/CactusValleyLE.SC2Map");
6, build F6
7, path to Feeder.exe is .../SC2Bot/x64/Debug/Feeder.exe