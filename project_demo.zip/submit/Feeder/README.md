Bot Feeder -- A StarCraft II bot

Feeder is a single faction (Terran) bot.

Reference and dependency:

SC2API - https://github.com/Blizzard/s2client-api by Blizzard

Basis - https://github.com/Archiatrus/CryptBot/tree/blank-bot from http://wiki.sc2ai.net/


This build was not finished yet!
TODO:
add how to use this project
clean up useless codes and add comments
make basic functionalities work
add documents

IF YOU REALLY WANT TO TRY, put it in the dir with same level of sc2api, make sure you have installed the map (put it in your game folder "Maps"), and run /x64/feeder.exe 
