Bot Feeder -- A StarCraft II bot

Feeder is a single faction (Terran) bot.

Reference and dependency:

SC2API - https://github.com/Blizzard/s2client-api by Blizzard

Basis - https://github.com/Archiatrus/CryptBot/tree/blank-bot from http://wiki.sc2ai.net/
